# Tool configuration
TAVILY_MAX_RESULTS = 5
